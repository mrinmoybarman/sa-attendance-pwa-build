const app = "SA-attendance";
const assets = [
  "/",
  "/index.html",
];


self.addEventListener("install", installEvent => {
  installEvent.waitUntil(
    caches.open(app).then(cache => {
      cache.addAll(assets);
    })
  );
});